/* This file is auto generated, version 201604200459 */
/* SMP */
#define UTS_MACHINE "arm"
#define UTS_VERSION "#201604200459 SMP Wed Apr 20 09:25:04 UTC 2016"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 4.9.2 (Ubuntu/Linaro 4.9.2-10ubuntu10) "
