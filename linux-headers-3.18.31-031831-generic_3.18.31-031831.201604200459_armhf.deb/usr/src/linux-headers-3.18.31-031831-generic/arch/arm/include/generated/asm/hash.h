#include <asm-generic/hash.h>
